#aqui são configurados os namespaces da app web que o Django usará para fazer o 
#roteamento entre das URLs às respectivas funções do controle (definidas no arquivo views.py) 
from django.urls import path
#importação das funções do fluxo de controle da app controle_bancario_app que estão definidas no arquivo views.py
from controle_bancario_app import views

#dependendo da quantidade de casos de uso, você precisa associar a função no fluxo de controle
#  (definidas em views.py) à interface (página html).
#Você precisa criar um path para que o Django possa fazer o roteamento das URLs às respectivas
# funções do controle (definidas no arquivo views.py) 
urlpatterns = [
    #Quando o usuário estiver na página web inicial "", o Django redirecionará o controle para 
    # a função home definida em views.py.
    path("", views.home, name="home"),
    #CRUDBLOCO
    path("criarBloco/", views.criarBloco, name="criarBloco"),
    path("visualizarBloco/", views.visualizarBloco, name="visualizarBloco"),
    path('deleteitem/<int:codigo>/', views.deleteitem, name='deleteitem'),
    path('edititem/<int:codigo>/', views.editar_item, name='edititem'),
    # CRUD SALA
    path("criarSala/", views.criarSala, name="criarSala"),
    path("excluirSala/", views.excluirSala, name="excluirSala"),
    path("atualizarSala/", views.atualizarSala, name="atualizarSala"),
    path("visualizarSala/", views.visualizarSala, name="visualizarSala"),
    # CRUD HORARIO
    path("criarCalendario/", views.criarCalendario, name="criarCalendario"),
    path("excluirCalendario/", views.excluirCalendario, name="excluirCalendario"),
    path("atualizarCalendario/", views.atualizarCalendario, name="atualizarCalendario"),
    path("visualizarCalendario/", views.visualizarCalendario, name="visualizarCalendario"),
    # CRUD UNIDADE
    path("criarUnidade/", views.criarUnidade, name="criarUnidade"),
    path("visualizarUnidade/", views.visualizarUnidade, name="visualizarUnidade"),
    path('deleteUnidade/<str:codigo>/', views.deleteUnidade, name='deleteUnidade'),
    path('editarUnidade/<str:codigo>/', views.editarUnidade, name='editarUnidade'),
    #CRUDBLOCO
    path("criarHorario/", views.criarHorario, name="criarHorario"),
    path("visualizarHorario/", views.visualizarHorario, name="visualizarHorario"),
    path('deleteHorario/<str:codigo>/', views.deleteHorario, name='deleteHorario'),
    path('editarHorario/<str:codigo>/', views.editarHorario, name='editarHorario'),
]