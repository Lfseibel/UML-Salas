from django.apps import AppConfig


class ControleBancarioAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'controle_bancario_app'
