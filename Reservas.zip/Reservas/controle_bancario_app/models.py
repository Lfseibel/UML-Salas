from distutils.archive_util import make_zipfile
from xml.parsers.expat import model
#biblioteca do django para trabalhar com o banco de dados
from django.db import models
from django.forms import CharField, Field
from django.utils import timezone
from datetime import time

class Bloco(models.Model):
    #lista de atributos com os tipos que deverão ser armazenados no banco
    codigo = models.IntegerField()
    nome = models.CharField(max_length=300)
    localizacao = models.CharField(max_length=300)
    
    # ********  Métodos da classe ************

    def criaBloco(self):
        self.save()
        
    def verificaBloco(codigoBloco):
        return Bloco.objects.filter(codigo=codigoBloco).exists()
    
    def editaBloco(codigo):
        return Bloco.objects.get(codigo = codigo)
    
    def removeBloco(codigo):
        item = Bloco.objects.get(codigo = codigo)
        item.delete()
        return
        
    def mostraBloco():
        return Bloco.objects.all() 
    

# SALA
class Sala(models.Model):
    codigo = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=100)
    unidade = models.CharField(max_length=100)
    blocoCodigo = models.CharField(max_length=100)
    capacidade = models.IntegerField()
    capacidadeReduzida = models.IntegerField()

    def registrarSala(self):
        self.save()
    
    def deletarSala(codigo):
        item = Sala.objects.get(codigo = codigo)
        item.delete()
        return
    def atualizarSala(self, novo_nome, nova_unidade,novo_blocoCodigo,nova_capacidade,nova_capacidadeReduzida):
        self.nome = novo_nome
        self.unidade = nova_unidade
        self.blocoCodigo = novo_blocoCodigo
        self.capacidade = nova_capacidade
        self.capacidadeReduzida = nova_capacidadeReduzida
        self.save()

    def verificaSala(codigoSala):
        return Sala.objects.filter(codigo=codigoSala).exists()
    
    def mostraSala():
        return Sala.objects.all() 

# HORARIO

class Calendario (models.Model):
    id = models.AutoField(primary_key=True)

    dataLimite = models.DateField()
    ano = models.IntegerField()
    semestre = models.IntegerField()
    InicioSemestre = models.DateField()
    FimSemestre = models.DateField()
        
    class Meta:
        unique_together = [['ano', 'semestre']]

    def save(self, *args, **kwargs):
        self.pk = self.combined_key()
        super().save(*args, **kwargs)

    def combined_key(self):
        return f'{self.ano}_{self.semestre}'
    
    def registrarCalendario(self):
        self.save()
    
    def deletarCalendario(id):
        item = Calendario.objects.get(id = id)
        item.delete()
        return

    def verificaCalendario(ano, semestre):
        test = f'{ano}_{semestre}'
        return Calendario.objects.filter(id=test,).exists()
    
    def verificaCalendarioID(id):
        return Calendario.objects.filter(id=id,).exists()

    def atualizarCalendario(self,nova_dataLimite,novo_ano,novo_semestre,novo_InicioSemestre,novo_FimSemestre):
        self.id = f'{novo_ano}_{novo_semestre}'
        self.dataLimite = nova_dataLimite
        self.ano = novo_ano
        self.semestre = novo_semestre
        self.InicioSemestre = novo_InicioSemestre
        self.FimSemestre = novo_FimSemestre

        self.save()

    def mostraCalendario():
        return Calendario.objects.all() 

class Unidade(models.Model):
    codigo = models.CharField(primary_key=True,max_length=10 )
    nome = models.CharField(max_length=100)

    def criaUnidade(self):
        self.save()
        
    def verificaUnidade(codigoUnidade):
        return Unidade.objects.filter(codigo=codigoUnidade).exists()
    
    def editaUnidade(codigo):
        return Unidade.objects.get(codigo = codigo)
    
    def removeUnidade(codigo):
        item = Unidade.objects.get(codigo = codigo)
        item.delete()
        return item
        
    def mostraUnidade():
        return Unidade.objects.all() 


class Horario(models.Model):
    #lista de atributos com os tipos que deverão ser armazenados no banco
    codigo = models.CharField(max_length=5)
    horaInicio = models.TimeField()
    horaFim = models.TimeField(default=time(12, 0, 0))
    
    def criaHorario(self):
        self.save()
        
    def verificaHorario(codigoHorario):
        return Horario.objects.filter(codigo=codigoHorario).exists()
    
    def editaHorario(codigo):
        return Horario.objects.get(codigo = codigo)
    
    def removeHorario(codigo):
        item = Horario.objects.get(codigo = codigo)
        item.delete()
        return item
        
    def mostraHorario():
        return Horario.objects.all() 