from datetime import datetime  #biblioteca python para trabalhar com datas
import random #biblioteca python para gerar numeros aleatorios
from http import client #biblioteca python para fazer conexão com um nó cliente. Esse nó seria o navegador do usuário final do nosso sistema
from django.shortcuts import render #biblioteca do django para enviar respostas usando o protocolo http
from django.shortcuts import redirect #biblioteca do django para redirecionar de uma interface web (página web) para outra - cria a navegação entre páginas web
from django.http import HttpResponse
from django.utils import timezone
from django.contrib import messages
#importações dos modelos (classes) necessários para o UC Abrir Conta
from controle_bancario_app.models import Bloco, Sala, Unidade, Horario, Calendario

# Inicio dos métodos que compõem o fluxo de controle a partir da interação do usuário com as interfaces web (página html).

def home(request):
    #método executado quando o usuário está na interface (paǵina html) inicial do sistema  home.html
    return render(request, "controle_bancario/home.html")

def criarBloco(request):
    if request.method == "POST":
        codigoBloco =  request.POST['codigoBloco'] 
        nomeBloco =  request.POST['nomeBloco']
        localizacaoBloco =  request.POST['localizacaoBloco'] 
        
        if(codigoBloco == '' or nomeBloco == '' or localizacaoBloco == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarBloco.html")



        if (verificaBloco(codigoBloco) == False):
        
            bloco = Bloco(
                codigo = codigoBloco,
                nome = nomeBloco,
                localizacao = localizacaoBloco    
            )
            bloco.criaBloco()
            messages.success(request, 'Bloco criado com sucesso.')
            
            return render(request, "controle_bancario/criarBloco.html")
        else:
            messages.success(request, 'Falha ao criar Bloco')
            return render(request, "controle_bancario/criarBloco.html")
        
    else:  
        # a solicitação (request) não contém dados (solicitação feita usando o metodo GET)
        # dessa forma será mostrado para o usuario final a página web de abertura de conta.
         return render(request, "controle_bancario/criarBloco.html")
    
    
def verificaBloco(codigoBloco):
    blocoExiste =  Bloco.verificaBloco(codigoBloco)
    return blocoExiste


def visualizarBloco(request):
    items = Bloco.mostraBloco()
    context = {
        'items': items
    }
    return render(request, "controle_bancario/visualizarBloco.html",context)


def deleteitem(request, codigo):
    Bloco.removeBloco(codigo)
    
    return redirect("visualizarBloco")
    
    
def editar_item(request, codigo):
    
    item = Bloco.editaBloco(codigo)

    if request.method == 'POST':
        item.nome = request.POST['nome']
        item.localizacao = request.POST['localizacao']
        if(request.POST['nome'] == '' or request.POST['localizacao'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/editarBloco.html")
        item.criaBloco()
        
        return redirect("visualizarBloco")

    context = {
        'item': item
    }
    return render(request, 'controle_bancario/editarBloco.html', context)

# SALAS-------------
def criarSala(request):
    if request.method == "POST":
        if(request.POST['codigo'] == '' or request.POST['nome'] == '' or request.POST['unidade'] == '' or request.POST['blocoCodigo'] == ''or request.POST['capacidade'] == '' or request.POST['capacidadeReduzida'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarSala.html")
        
        if(not verificaUnidade(request.POST['unidade'])):
            messages.success(request, 'Unidade não existe')
            return render(request, "controle_bancario/criarSala.html")
        
        if(not verificaBloco(request.POST['blocoCodigo'])):
            messages.success(request, 'Bloco não existe')
            return render(request, "controle_bancario/criarSala.html")

        sala = registrarSala(request)
        return redirect("visualizarSala")  # Substitua "nome_da_rota" pela rota correta para a página de redirecionamento

    else:
         return render(request, "controle_bancario/criarSala.html")

def registrarSala(request):
    sala = Sala(
        codigo=request.POST['codigo'],
        nome=request.POST['nome'],
        unidade=request.POST['unidade'],
        blocoCodigo=request.POST['blocoCodigo'],
        capacidade=request.POST['capacidade'],
        capacidadeReduzida=request.POST['capacidadeReduzida'],
    )
    sala.registrarSala()
    return sala

def excluirSala(request):
    if request.method == "POST":
        codigo = request.POST['codigo']
        if(request.POST['codigo'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/excluirSala.html")
        if(not Sala.verificaSala(codigo)):
            messages.success(request, 'Sala não existe')
            return render(request, "controle_bancario/excluirSala.html")
        Sala.deletarSala(codigo)
        return redirect("excluirSala")
    else:
         return render(request, "controle_bancario/excluirSala.html")

def atualizarSala(request):
    if request.method == 'POST':
        codigo = request.POST.get('codigo')
        novo_nome = request.POST.get('nome')
        novo_blocoCodigo = request.POST.get('blocoCodigo')
        nova_capacidade = request.POST.get('capacidade')
        nova_capacidadeReduzida = request.POST.get('capacidadeReduzida')
        nova_unidade = request.POST.get('unidade')
        
        if(request.POST['codigo'] == '' or request.POST['nome'] == '' or request.POST['unidade'] == '' or request.POST['blocoCodigo'] == ''or request.POST['capacidade'] == '' or request.POST['capacidadeReduzida'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/atualizarSala.html")
        
        if(not verificaUnidade(request.POST['unidade'])):
            messages.success(request, 'Unidade não existe')
            return render(request, "controle_bancario/atualizarSala.html")
        
        if(not verificaBloco(request.POST['blocoCodigo'])):
            messages.success(request, 'Bloco não existe')
            return render(request, "controle_bancario/atualizarSala.html")
        
        try:
            sala = Sala.objects.get(codigo=codigo)
            sala.atualizarSala(novo_nome, nova_unidade,novo_blocoCodigo,nova_capacidade,nova_capacidadeReduzida)
            return redirect('atualizarSala')
        except Sala.DoesNotExist:
            return redirect('atualizarSala')
    
    return render(request, 'controle_bancario/atualizarSala.html')

def visualizarSala(request):
    salas = Sala.mostraSala()
    return render(request, "controle_bancario/visualizarSala.html",{'salas':salas})

# HORARIOS -------------

def criarCalendario(request):
    if request.method == "POST":
        if(request.POST['dataLimite'] == '' or request.POST['ano'] == '' or request.POST['semestre'] == '' or request.POST['InicioSemestre'] == ''or request.POST['FimSemestre'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarCalendario.html")
        if(Calendario.verificaCalendario(request.POST['ano'],request.POST['semestre'])):#problema aqui, não diferencias entre 2022,1 e 2022,2
            messages.success(request, 'Ja existe um calendario nesse ano/semestre')
            return render(request, "controle_bancario/criarCalendario.html")
        if (request.POST['InicioSemestre'] < request.POST['FimSemestre']) and (request.POST['FimSemestre'] >= request.POST['dataLimite'] )and (request.POST['InicioSemestre'] <= request.POST['dataLimite']):
            calendario = Calendario(
                dataLimite=request.POST['dataLimite'],
                ano=request.POST['ano'],
                semestre=request.POST['semestre'],
                InicioSemestre=request.POST['InicioSemestre'],
                FimSemestre=request.POST['FimSemestre'],
            )
            calendario.registrarCalendario()
            return redirect("visualizarCalendario")
        else: 
            messages.success(request, 'Datas invalidas, ou o semestre inicial é menor que o final, ou a data limite não é entre as outras datas')
            return render(request, "controle_bancario/criarCalendario.html")
    else:
         return render(request, "controle_bancario/criarCalendario.html")

    
def excluirCalendario(request):
    if request.method == "POST":
        id = request.POST['id']
        if(request.POST['id'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/excluirCalendario.html")
        if(Calendario.verificaCalendarioID(request.POST['id'])):
            Calendario.deletarCalendario(id)
            messages.success(request, 'Excluido com sucesso')
            return render(request, "controle_bancario/excluirCalendario.html")
        else:
            messages.success(request, 'Não existe esse calendario')
            return render(request, "controle_bancario/excluirCalendario.html")
    else:
         return render(request, "controle_bancario/excluirCalendario.html")

def atualizarCalendario(request):
    if request.method == 'POST':
        if(request.POST['dataLimite'] == '' or request.POST['ano'] == '' or request.POST['semestre'] == '' or request.POST['InicioSemestre'] == ''or request.POST['FimSemestre'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarCalendario.html")
        if(Calendario.verificaCalendario(request.POST['ano'],request.POST['semestre'])):#problema aqui, não diferencias entre 2022,1 e 2022,2
            messages.success(request, 'Ja existe um calendario nesse ano/semestre')
            return render(request, "controle_bancario/criarCalendario.html")
        if (request.POST['InicioSemestre'] < request.POST['FimSemestre']) and (request.POST['FimSemestre'] >= request.POST['dataLimite'] )and (request.POST['InicioSemestre'] <= request.POST['dataLimite']):
            id = request.POST.get('id')
            calendario = Calendario(
                dataLimite=request.POST['dataLimite'],
                ano=request.POST['ano'],
                semestre=request.POST['semestre'],
                InicioSemestre=request.POST['InicioSemestre'],
                FimSemestre=request.POST['FimSemestre'],
            )
            calendario.registrarCalendario()
        
    return render(request, 'controle_bancario/atualizarCalendario.html')


def visualizarCalendario(request):
    calendarios = Calendario.mostraCalendario()
    return render(request, "controle_bancario/visualizarCalendario.html",{'calendarios':calendarios})


# Função para mandar para a tela atualizar unidade
def criarUnidade(request):
    if request.method == "POST":
        codigoUnidade =  request.POST['codigo'] 
        nome =  request.POST['nome']

        if(codigoUnidade == '' or nome == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarUnidade.html")

        if (verificaUnidade(codigoUnidade) == False):
        
            unidade = Unidade(
                codigo = codigoUnidade,
                nome = nome, 
            )
            unidade.criaUnidade()
            messages.success(request, 'Unidade criada com sucesso.')
            
            return render(request, "controle_bancario/criarUnidade.html")
        else:
            messages.success(request, 'Unidade já existente')
            return render(request, "controle_bancario/criarUnidade.html")
        
    else:  
        # a solicitação (request) não contém dados (solicitação feita usando o metodo GET)
        # dessa forma será mostrado para o usuario final a página web de abertura de conta.
         return render(request, "controle_bancario/criarUnidade.html")
    
    
def verificaUnidade(codigoUnidade):
    unidadeExiste =  Unidade.verificaUnidade(codigoUnidade)
    return unidadeExiste


def visualizarUnidade(request):
    items = Unidade.mostraUnidade()
    context = {
        'items': items
    }
    return render(request, "controle_bancario/visualizarUnidade.html",context)


def deleteUnidade(request, codigo):
    Unidade.removeUnidade(codigo)
    
    return redirect("visualizarUnidade")
    
    
def editarUnidade(request, codigo):
    
    item = Unidade.editaUnidade(codigo)

    if request.method == 'POST':

        item.nome = request.POST['nome']
        if(request.POST['nome'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/editarUnidade.html")
        item.criaUnidade()
        
        return redirect("visualizarUnidade")

    context = {
        'item': item
    }
    return render(request, 'controle_bancario/editarUnidade.html', context)



#Horarios
def criarHorario(request):
    if request.method == "POST":
        codigoHorario =  request.POST['codigoHorario'] 
        horaInicio =  request.POST['horaInicio']
        horaFim =  request.POST['horaFim'] 
        
        if(codigoHorario == '' or horaInicio == '' or horaFim == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarHorario.html")

        if(horaInicio > horaFim or horaFim == horaInicio):
            messages.success(request, 'Hora final tem que ser maior que a inicial')
            return render(request, "controle_bancario/criarHorario.html")

        if (verificaHorario(codigoHorario) == False):
        
            horario = Horario(
                codigo = codigoHorario,
                horaInicio = horaInicio,
                horaFim = horaFim    
            )
            horario.criaHorario()
            messages.success(request, 'Horario criado com sucesso.')
            
            return render(request, "controle_bancario/criarHorario.html")
        else:
            messages.success(request, 'Já existe um horario com esse codigo')
            return render(request, "controle_bancario/criarHorario.html")
        
    else:  
        # a solicitação (request) não contém dados (solicitação feita usando o metodo GET)
        # dessa forma será mostrado para o usuario final a página web de abertura de conta.
         return render(request, "controle_bancario/criarHorario.html")
    
    
def verificaHorario(codigoHorario):
    horarioExiste =  Horario.verificaHorario(codigoHorario)
    return horarioExiste


def visualizarHorario(request):
    items = Horario.mostraHorario()
    context = {
        'items': items
    }
    return render(request, "controle_bancario/visualizarHorario.html",context)


def deleteHorario(request, codigo):
    Horario.removeHorario(codigo)
    
    return redirect("visualizarHorario")
    
    
def editarHorario(request, codigo):
    
    item = Horario.editaHorario(codigo)

    if request.method == 'POST':
        if(request.POST['horaInicio'] == '' or request.POST['horaFim'] == ''):
            messages.success(request, 'Preencha corretamente')
            return render(request, "controle_bancario/criarHorario.html")
        if(request.POST['horaInicio'] > request.POST['horaFim'] or request.POST['horaFim'] == request.POST['horaInicio']):
            messages.success(request, 'Hora final tem que ser maior que a inicial')
            return render(request, "controle_bancario/editarHorario.html")
        item.horaInicio = request.POST['horaInicio']
        item.horaFim = request.POST['horaFim']
        
        item.criaHorario()
        
        return redirect("visualizarHorario")

    context = {
        'item': item
    }
    return render(request, 'controle_bancario/editarHorario.html', context)

